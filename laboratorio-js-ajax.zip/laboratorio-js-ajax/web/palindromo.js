function esPalindromo(cad){
  const limpia = cad.toLowerCase().replace(/[^a-z0-9áéíóúüñ]/g,'');
  return limpia && limpia === limpia.split('').reverse().join('');
}
document.getElementById('btnPal').addEventListener('click', ()=>{
  const t = document.getElementById('texto').value;
  const r = document.getElementById('resPal');
  if(!t.trim()){ r.textContent='Introduce texto.'; return; }
  r.textContent = esPalindromo(t) ? `"${t}" SÍ es palíndromo.` : `"${t}" NO es palíndromo.`;
});
