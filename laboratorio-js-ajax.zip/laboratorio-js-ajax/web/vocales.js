document.getElementById('btnFind').addEventListener('click', ()=>{
  const s = document.getElementById('fr').value.toLowerCase();
  const arr = s.match(/[aeiouáéíóúü]/g) || [];
  const unicas = [...new Set(arr)].sort();
  document.getElementById('resVoc').textContent = unicas.length ? `Vocales: ${unicas.join(', ')}` : 'No se encontraron vocales.';
});
document.getElementById('btnCount').addEventListener('click', ()=>{
  const s = document.getElementById('fr').value.toLowerCase();
  const map = {a:0,e:0,i:0,o:0,u:0};
  for(const ch of s){
    if('áàäâ'.includes(ch)) map.a++;
    else if('éèëê'.includes(ch)) map.e++;
    else if('íìïî'.includes(ch)) map.i++;
    else if('óòöô'.includes(ch)) map.o++;
    else if('úùüû'.includes(ch)) map.u++;
    else if(map.hasOwnProperty(ch)) map[ch]++;
  }
  document.getElementById('resVoc').textContent = `A:${map.a} E:${map.e} I:${map.i} O:${map.o} U:${map.u}`;
});
