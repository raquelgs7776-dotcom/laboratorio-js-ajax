document.addEventListener('DOMContentLoaded', ()=> {
  const input = document.getElementById('url');
  input.value = window.location.href;
  const btn = document.getElementById('btnLoad');
  const estado = document.getElementById('estado');
  const codigo = document.getElementById('codigo');
  const cab = document.getElementById('cabeceras');
  const cont = document.getElementById('contenido');

  async function doFetch(url){ return fetch(url); }

  btn.addEventListener('click', async ()=>{
    const url = input.value.trim();
    if(!url){ estado.textContent='Introduce una URL'; return; }
    btn.disabled = true; estado.textContent='Cargando...';
    cab.textContent=''; cont.textContent=''; codigo.textContent='-';
    try{
      let resp;
      try { resp = await doFetch(url); }
      catch(errDirect){
        console.warn('Direct failed:', errDirect);
        const proxy = 'https://api.allorigins.win/raw?url=';
        resp = await doFetch(proxy + encodeURIComponent(url));
      }
      codigo.textContent = `${resp.status} ${resp.statusText}`;
      try { resp.headers.forEach((v,n)=> cab.textContent += `${n}: ${v}\n`); } catch(e){}
      const text = await resp.text();
      cont.textContent = text.length>20000 ? text.slice(0,20000) + '\n\n[Contenido truncado]' : text;
      estado.textContent = resp.ok ? 'Completado' : 'Completado con error';
    } catch(err){
      estado.textContent = 'Error en la petición';
      cont.textContent = err.message || String(err);
      console.error('Final fetch error:', err);
    } finally { btn.disabled = false; }
  });
});

