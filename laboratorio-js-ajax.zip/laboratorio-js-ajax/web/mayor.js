document.getElementById('btnMay').addEventListener('click', ()=>{
  const a = Number(document.getElementById('n1').value);
  const b = Number(document.getElementById('n2').value);
  const r = document.getElementById('resMay');
  if(isNaN(a) || isNaN(b)){ r.textContent='Introduce dos números válidos.'; return; }
  r.textContent = a>b ? `${a} es mayor que ${b}` : (b>a ? `${b} es mayor que ${a}` : 'Los números son iguales.');
});
 